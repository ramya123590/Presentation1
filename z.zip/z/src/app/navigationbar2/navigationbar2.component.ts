import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigationbar2',
  templateUrl: './navigationbar2.component.html',
  styleUrls: ['./navigationbar2.component.css']
})
export class Navigationbar2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
