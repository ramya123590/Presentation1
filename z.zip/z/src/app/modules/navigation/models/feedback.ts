export class Feedback {
    constructor(public name:string, public feedbackMessage:string,  public experience:String){}
}
