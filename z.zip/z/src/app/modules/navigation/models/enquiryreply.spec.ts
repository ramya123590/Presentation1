import { Enquiryreply } from './enquiryreply';

describe('Enquiryreply', () => {
  it('should create an instance', () => {
    expect(new Enquiryreply()).toBeTruthy();
  });
});
