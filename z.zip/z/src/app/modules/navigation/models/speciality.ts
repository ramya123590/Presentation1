export class Speciality {

        constructor( public speciality_name:string){}
         
    
}
