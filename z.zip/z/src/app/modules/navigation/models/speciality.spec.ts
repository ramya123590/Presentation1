import { Speciality } from './speciality';

describe('Speciality', () => {
  it('should create an instance', () => {
    expect(new Speciality()).toBeTruthy();
  });
});
