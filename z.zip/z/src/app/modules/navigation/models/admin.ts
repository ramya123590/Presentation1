export class Admin {

    admin_count : number;
   constructor(public admin_password:string,public  admin_userName:string ){} 

   
}
