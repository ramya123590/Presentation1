export class Branch {
    branch:String
}
