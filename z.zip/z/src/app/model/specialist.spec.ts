import { Specialist } from './specialist';

describe('Specialist', () => {
  it('should create an instance', () => {
    expect(new Specialist()).toBeTruthy();
  });
});
