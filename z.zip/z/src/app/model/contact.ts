export class Contact {
    constructor( public feedbackMessage:string,  public rate:number, public userMail:string){}
}
