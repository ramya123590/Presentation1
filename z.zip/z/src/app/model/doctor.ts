export class Doctor {

    doctor_id:Number
	
	 firstName : String;
	

	  lastName :String;
	
	
	
	
	  specialist :String;
	
	
	
	 branch: String;
	
	
	
	  fee:Number;
	
}
