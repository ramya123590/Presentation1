export class loginUser{
    constructor(public userId:string , public password:string ){}
}