export class Specialist {
    specialist:String
}
