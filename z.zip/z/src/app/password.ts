export interface User {
    password: string;
    confirmPassword: string;
}